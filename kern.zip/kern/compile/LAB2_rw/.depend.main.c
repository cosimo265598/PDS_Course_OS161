main.o: ../../main/main.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/kern/errno.h \
 ../../include/kern/reboot.h ../../include/kern/unistd.h \
 ../../include/lib.h ../../include/cdefs.h opt-noasserts.h \
 ../../include/spl.h ../../include/clock.h ../../include/kern/time.h \
 ../../include/thread.h ../../include/array.h ../../include/spinlock.h \
 includelinks/machine/spinlock.h ../../include/threadlist.h \
 includelinks/machine/thread.h ../../include/setjmp.h \
 includelinks/kern/machine/setjmp.h ../../include/proc.h \
 ../../include/current.h includelinks/machine/current.h \
 ../../include/synch.h ../../include/vm.h includelinks/machine/vm.h \
 ../../include/mainbus.h ../../include/vfs.h ../../include/device.h \
 ../../include/syscall.h ../../include/test.h ../../include/version.h \
 autoconf.h ../../include/hello.h ../../include/mysyscall.h opt-syscall.h
