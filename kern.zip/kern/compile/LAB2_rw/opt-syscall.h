/* Automatically generated; do not edit */
#ifndef _OPT_SYSCALL_H_
#define _OPT_SYSCALL_H_
#define OPT_SYSCALL 1
#endif /* _OPT_SYSCALL_H_ */
